class Error(Exception):
    ...


class Forbidden(Error):
    ...


class NotFound(Error):
    ...
